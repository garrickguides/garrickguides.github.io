# Practice Models for Bambu Studio for New Owners

Eight small test prints, one for each kind of check the book teaches. Each one goes with a chapter: print it, look at the result, and the chapter tells you what to change.

Every model was designed for a 0.4 mm nozzle, PLA (Bambu PLA Basic or similar) and the **0.20mm Standard** system preset for your printer, and every part fits the 180 x 180 mm plate of the A1 mini, except the one file marked 256.

## Before you print any of them

1. In Studio, set the four choices from Chapter 2: your printer, the plate on the bed, your filament, and **0.20mm Standard @BBL** for your printer, with no asterisk on the preset name.
2. Click **Add [Ctrl+I]** and open the .stl file. It holds only the shape, no settings, so your own printer, plate, filament and process presets stay in charge.
3. Do not scale the models. The sizes below are part of the test.
4. Click **Slice plate** and check the first layer in **Preview** (Chapter 4, Judge a First Layer in Ten Seconds).

Filament amounts below are rough estimates for the system preset (2 walls, 15 % infill). After slicing, the **Slicing Result** panel shows the real figure.

---

## 1. first-layer-test

**What it is:** five thin squares, 30 x 30 x 0.4 mm (two layers), placed at the four corners and the center of the plate.

**Files:** `first-layer-test-180` for the A1 mini (layout 160 x 160 mm). `first-layer-test-256` for printers with a 256 mm plate, such as the A1, P1S and P2S (layout 226 x 226 mm). The 256 file does not fit an A1 mini.

**Book:** Chapter 4, Judge a First Layer in Ten Seconds; Tell Studio Which Plate Is on the Printer; Leave the Z Offset to the Printer.

**Settings:** the system preset as it is. **Enable support** off, as in the preset. **Brim type** on **Auto**.

**After printing:** look at each square before you take it off, then hold it up to a light. Compare all five with the table in Chapter 4:

- Flat lines that touch, forming one even sheet: a good first layer.
- Round strands with gaps: nozzle too high. Check the plate tile first.
- Thin, rough lines with ridges between them: nozzle too low. Check the nozzle tip, then rerun the calibration.
- Good in some squares and loose in others: often oil on the plate where fingers touched. Give the plate the two-minute wash and print it again.

If one corner stays different after a wash, rerun the auto bed leveling calibration from Bambu Handy (Chapter 4).

**Filament:** about 2 g.

---

## 2. stringing-towers

**What it is:** two round towers, 8 mm wide and 40 mm tall, 60 mm apart, on a thin shared base. The nozzle has to travel across open air between them on every layer.

**Book:** Chapter 10, Strings, Wisps and 'Cotton Candy', with See the Travel Moves Before You Print.

**Settings:** first print with the system preset as it is, so you have a starting point. Before you slice, tick **Travel** and **Retract** in the display options of the **Slicing Result** panel to see the paths where strings can form.

**After printing:** look between the towers. A few wisps that brush away with a fingertip are fine. Many threads, or a web ("cotton candy"), mean you should work down the Chapter 10 list, one change per print:

1. Dry the spool (Chapter 5). This is the Check This First.
2. Lower the nozzle temperature in small steps: **Filament settings > Filament > Print temperature**, the **Nozzle** row, **Other layers** column, inside the range on the spool label.
3. Raise the retraction **Length** in small steps on **Setting Overrides** (stay at or below about 2 mm), or, instead, **Retraction Speed**.

Print a new pair of towers after each change and keep the old ones to compare.

**Filament:** about 5 g.

---

## 3. overhang-ladder

**What it is:** a wall with six tabs sticking out of the front. The underside of each tab slopes at the angle engraved below it: 20, 30, 40, 50, 60 and 70 degrees.

The numbers are measured from the plate (the horizontal), the same way Studio measures **Threshold angle**. So 70 is steep and easy to print, and 20 is almost flat and hard. Other overhang tests you find online often measure the other way, from the vertical.

**Book:** Chapter 6, Turn the Part Before You Add Supports; Chapter 10, Rough Tops, Saggy Overhangs and Messy Bridges.

**Settings:** **Enable support** off, as in the preset. This print is meant to show where your printer stops coping without support.

**Before printing, try this on screen:** on the **Prepare** tab press Ctrl+L (**Show Overhang**), then Ctrl+2 for the bottom view. Studio marks the tabs that are flatter than the **Threshold angle** (30 degrees in the system presets). Those are the tabs that would get support if you ticked **Enable support**.

**After printing:** look at the underside of each tab from the front and below. The 20 tab will droop and curl; that is expected. Find the lowest number whose underside is still smooth and whose edge is still straight. Tabs below that number are the angles that need support or a better orientation on your printer, with this filament.

If the droop starts at a higher number than you expected, work through Chapter 10, one change per print: check that **Slow down for overhangs** is ticked on **Process > Speed** (Advanced on), then raise the part cooling fan in small steps on **Filament settings > Cooling**, **Part cooling fan** group.

**Filament:** about 20 g. This is the heaviest model in the pack.

---

## 4. bridge-test

**What it is:** four bridges, flat spans with nothing under them, between pairs of pillars. The spans are 10, 20, 30 and 40 mm, engraved on the base beside each one. Each bridge is 8 mm above the base.

**Book:** Chapter 10, Rough Tops, Saggy Overhangs and Messy Bridges (For a sagging bridge).

**Settings:** **Enable support** off, as in the preset. Studio has to bridge these spans in midair.

**After printing:** look at each bridge from the side and from below. Good bridges have tight strands that touch each other. Loose strands sagging in the middle show where your printer's limit is. The 40 mm span is the hardest.

If the longer bridges sag, print a second copy with **Thick bridges** ticked on **Process > Quality** (Advanced on), and leave **Bridge flow** at 1. Compare the two copies side by side. Studio's tooltip says thick bridges are more reliable over longer spans but may look worse.

**Filament:** about 14 g.

---

## 5. support-practice

**What it is:** the part from Figure 6.2: a block with a shelf sticking out at mid height, plus a 10 mm round hole lying on its side through the lower part of the block, front to back.

**Book:** Chapter 6, all of it: Normal or Tree, Automatic or Painted; Turn Supports On and See Them; Gap and Interface; Keep Supports Out of Holes and Off Visible Faces.

**Settings:** tick **Process > Support > Enable support**. Without it, the shelf prints in midair and fails.

**Practice on screen first, no printing needed:**

1. With **Type** on **tree(auto)**, click **Slice plate**. In **Slicing Result**, set **Color Scheme** to **Line Type** and note the weight.
2. Change **Type** to **normal(auto)** and slice again. Compare the shape under the shelf and the weight (Figure 6.2 shows both).
3. Look inside the hole: Studio grows support in it. Try each of the three ways to keep it out, one at a time: tick **On build plate only**; paint a block inside the hole with **Supports Painting** [L] and the right mouse button; or add a **Support blocker**.

For the blocker, follow The Volume Way in Chapter 6 with these numbers: **Size** X 12, Y 24, Z 12. Set its **Position** Y to the block's Y value, its **Position** X to the block's X value minus 12.5, and its **Position** Z to 9 (the hole's center is 9 mm above the plate). Press Ctrl+3 for the front view and check that the blocker fills the hole; if it does not, drag it into place.

**After printing (optional):** print it once with **tree(auto)** and pull the support off by hand. If it will not come off, try Loosen a Support That Welds On (Chapter 6). The underside of the shelf will show where the support touched it.

**Filament:** about 10 g, plus the support.

---

## 6. color-change-nameplate

**What it is:** a plate 80 x 25 x 2 mm with the raised words MY FIRST / COLOR CHANGE, 1.5 mm high. The letters start at 2.0 mm, so one color change at that height prints the plate in one color and the letters in another.

**Book:** Chapter 7, Change Color at a Layer (with an AMS or AMS lite), or Color Without an AMS: Pause and Swap (one spool at a time).

**Settings:** the system preset as it is. **Enable support** off. **Print sequence** on **By layer** (**Process > Others**), as in the preset.

**Find the layer:** with **0.20mm Standard**, the first layer of the letters is layer 11, about 2.2 mm on the slider. Right-click the upper handle of the layer slider, choose **Jump to Layer** and type 11. Check that the top of the view shows only letters. If you changed **Initial layer height**, the number moves; drag the handle until the top of the view shows the first layer with only letters.

- **With an AMS or AMS lite:** right-click the handle, point to **Change Filament**, click **Filament 2**, then click **Slice plate**. **Filament change times** in **Slicing Result** should read 1.
- **Without an AMS:** right-click the handle and click **Add Pause**, then click **Slice plate**. When the printer stops, swap the spool as in Chapter 7.

**After printing:** the plate is one color and the letters another. A trace of the old color in the first lines of the letters is normal after a pause, because there is no purge.

**Filament:** about 6 g.

---

## 7. filament-swatch

**What it is:** a 70 x 40 x 2 mm card with a ring hole in one corner, a recessed panel to write on with a permanent marker, and four thin steps along the bottom edge, 0.4, 0.8, 1.2 and 1.6 mm thick, labeled above. Print one per spool and keep them on a ring.

**Book:** Chapter 5, Bambu or Another Brand: Choosing the Right Profile, and Store Spools So the Next Print Starts Dry.

**Settings:** the system preset as it is, with the filament preset that matches the spool. **Enable support** off.

**After printing:** hold the card up to a light. The thin steps show how much light passes through this filament and how the color changes with thickness. On the panel, write what you will want to know next time, for example: brand, type and color, the filament preset you used in Studio, and the date of the last drying (Chapter 5).

**Filament:** about 6 g.

---

## 8. size-check

**What it is:** a 20 mm cube with a 10 mm hole straight down through it. The letters X and Y on two faces show which direction you are measuring.

**Book:** Chapter 10, Parts That Do Not Fit: Elephant Foot and Size Errors, with Measure the Part Against Studio.

**Settings:** the system preset as it is. **Enable support** off. Do not rotate the cube on the plate, so the X face stays facing the X direction.

**After printing:** you need a caliper, or at least a ruler with millimeter marks.

1. Measure across the cube from the face marked X to the face opposite it, then from the face marked Y to the face opposite it, then the height. Studio's **Size** for this model is 20 x 20 x 20 mm.
2. Measure the hole across, in the X direction and in the Y direction. In Studio, **Measure** [U] shows the hole as drawn: 10 mm.
3. Look at the bottom edge: a lip that sticks out wider than the walls above it is elephant foot.

What the numbers tell you, from Chapter 10:

- Too large in every direction: run the **Flow Rate** calibration (Chapter 5) before you change anything else.
- Wrong in one direction only, or a hole that measures differently across X and Y: points to the machine (Chapter 13, belts).
- A lip at the bottom: raise **Elephant foot compensation** in small steps on **Process > Quality**, **Precision** group (Advanced on). The preset value is 0.075 mm.

**Filament:** about 4 g.

---

## At a glance

| Model | Size (mm) | Filament | Supports | Book |
|---|---|---|---|---|
| first-layer-test-180 | 160 x 160 x 0.4 (five squares) | 2 g | Off | Ch. 4 |
| first-layer-test-256 | 226 x 226 x 0.4 (five squares) | 2 g | Off | Ch. 4 |
| stringing-towers | 76 x 16 x 40 | 5 g | Off | Ch. 10 |
| overhang-ladder | 92 x 28 x 34.5 | 20 g | Off | Ch. 6, Ch. 10 |
| bridge-test | 68 x 54 x 12 | 14 g | Off | Ch. 10 |
| support-practice | 50 x 20 x 40 | 10 g + support | On | Ch. 6 |
| color-change-nameplate | 80 x 25 x 3.5 | 6 g | Off | Ch. 7 |
| filament-swatch | 70 x 40 x 2 | 6 g | Off | Ch. 5 |
| size-check | 20 x 20 x 20 | 4 g | Off | Ch. 10 |

The whole pack, one of each, uses about 70 g of filament.

## License

All models in this pack are original designs, released under CC BY 4.0 by Owen T. Garrick. You may print, share and change them, also commercially, as long as you credit Owen T. Garrick. Full license text: https://creativecommons.org/licenses/by/4.0/

Checked on 2026-10-26: the models load and slice in Bambu Studio 2.8.2.61 (Bambu Lab A1, 0.20mm Standard @BBL A1, PLA Basic). With supports off, Studio warns that support-practice has a floating cantilever, which is the point of that part: turn **Enable support** on for it, as its block says.
